/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aulajavamysql;

/**
 *
 * @author Luiz Bataioli
 */
public class AulaJavaMySql {

    public static void main(String[] args) {
        
        frmCadastroPessoa formCadastroPessoa = new frmCadastroPessoa();
        formCadastroPessoa.setVisible(true);
        
        
    }
}
